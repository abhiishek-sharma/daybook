import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { BarChart, Bar, ResponsiveContainer, Cell } from 'recharts';
import { motion } from 'motion/react';
import { Settings, LogIn } from 'lucide-react';

const chartData = [
  { value: 40 }, { value: 55 }, { value: 35 }, { value: 65 }, 
  { value: 85 }, { value: 45 }, { value: 50 }, { value: 60 }, 
  { value: 40 }, { value: 30 }
];

// --- Habit Screen ---
function Habits() {
  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <section className="glass-panel rounded-3xl p-8 md:p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-tertiary/5 rounded-full blur-[100px]"></div>
        <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-12">
          <div>
            <p className="font-sans text-xs text-tertiary mb-2 uppercase tracking-widest font-semibold">Current Alignment</p>
            <h2 className="font-display text-4xl md:text-5xl text-on-surface mb-4 leading-tight">Celestial Consistency</h2>
            <div className="flex gap-8">
              <div>
                <span className="block text-2xl font-display text-primary">42 Days</span>
                <span className="text-xs font-sans text-on-surface-variant uppercase tracking-wider">Active Streak</span>
              </div>
              <div className="w-px h-10 bg-white/10 self-center"></div>
              <div>
                <span className="block text-2xl font-display text-primary">1,240</span>
                <span className="text-xs font-sans text-on-surface-variant uppercase tracking-wider">Total Observations</span>
              </div>
            </div>
          </div>
          <div className="hidden md:block text-right">
            <p className="text-sm text-on-surface-variant italic opacity-70 max-w-[200px]">
              "Consistency is the light that defines your internal universe."
            </p>
          </div>
        </div>
        
        <div className="w-full overflow-x-auto pb-4 scrollbar-hide">
          <div className="inline-grid grid-rows-7 grid-flow-col gap-2">
            {Array.from({ length: 364 }).map((_, i) => {
              const active = Math.random() > 0.3;
              const intensity = Math.random();
              return (
                <div 
                  key={i}
                  className={`w-3 h-3 rounded-full transition-all duration-500 ${active ? 'bg-tertiary' : 'bg-white/5'} ${active && intensity > 0.8 ? 'star-bloom scale-110' : ''}`}
                  style={{ opacity: active ? 0.2 + intensity * 0.8 : 1 }}
                />
              )
            })}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <HabitCard title="Deep Meditation" streak={24} icon="🧘" />
        <HabitCard title="Stellar Reading" streak={12} icon="📖" />
        <HabitCard title="Hydration Flow" streak={42} icon="💧" />
      </section>
    </div>
  );
}

function HabitCard({ title, streak, icon }: { title: string, streak: number, icon: string }) {
  return (
    <div className="glass-card rounded-2xl p-6 flex flex-col gap-6 hover:border-tertiary/30 transition-all duration-500 group cursor-pointer">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full glass-panel flex items-center justify-center text-2xl">
            {icon}
          </div>
          <div>
            <h3 className="font-display text-xl text-on-surface">{title}</h3>
            <p className="text-xs text-on-surface-variant uppercase tracking-wider">Active Cycle</p>
          </div>
        </div>
        <div className="w-10 h-10 rounded-full border border-tertiary/50 flex items-center justify-center text-tertiary group-hover:bg-tertiary group-hover:text-on-tertiary transition-all duration-300">
          <span className="text-lg">✓</span>
        </div>
      </div>
      <div className="flex justify-between items-end">
        <div>
          <span className="text-3xl font-display text-tertiary">{streak}</span>
          <span className="ml-2 text-xs text-on-surface-variant">Day Streak</span>
        </div>
        <div className="flex gap-1">
          {Array.from({ length: 7 }).map((_, i) => (
            <div key={i} className={`w-1.5 h-1.5 rounded-full ${i < streak % 7 ? 'bg-tertiary' : 'bg-white/10'}`} />
          ))}
        </div>
      </div>
    </div>
  );
}

// --- Finance Screen ---
function Finance() {
  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-panel rounded-3xl p-8 flex flex-col justify-center min-h-[220px] relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-tertiary/5 rounded-full blur-[80px]"></div>
          <span className="text-xs text-on-surface-variant uppercase tracking-widest font-semibold mb-2">Total Wealth</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-display text-tertiary">$</span>
            <span className="text-5xl font-display text-on-surface">42,890.00</span>
          </div>
          <div className="mt-6 flex items-center gap-2 text-primary text-sm">
            <span>↗ +2.4% from last moon cycle</span>
          </div>
        </div>

        <div className="glass-panel rounded-3xl p-8 flex flex-col justify-between">
          <div>
            <span className="text-xs text-on-surface-variant uppercase tracking-widest font-semibold mb-2">Monthly Orbit</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-display text-primary">$</span>
              <span className="text-3xl font-display text-on-surface">3,240.50</span>
            </div>
          </div>
          <div className="mt-8">
            <div className="flex justify-between text-xs text-on-surface-variant uppercase mb-2">
              <span>Budget Ceiling</span>
              <span className="text-tertiary">72% Utilized</span>
            </div>
            <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-tertiary/40 to-tertiary w-[72%] rounded-full shadow-[0_0_10px_rgba(233,195,73,0.3)]"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="glass-panel rounded-3xl p-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="font-display text-2xl text-primary">Spending Trajectory</h2>
          <div className="flex gap-2">
            <span className="text-xs px-3 py-1 bg-tertiary/20 text-tertiary rounded-full font-bold">30 Days</span>
            <span className="text-xs px-3 py-1 text-on-surface-variant/40 rounded-full font-bold">90 Days</span>
          </div>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {chartData.map((_entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 4 ? '#e9c349' : '#e9c349'} fillOpacity={index === 4 ? 0.8 : 0.2} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="font-display text-2xl text-primary">Recent Flux</h2>
          <button className="text-xs text-on-surface-variant font-bold uppercase tracking-widest hover:text-tertiary transition-colors">View Archives</button>
        </div>
        <div className="space-y-4">
          <TransactionItem title="Celestial Dining" amount="-124.00" category="Gastronomy" date="Today" color="tertiary" />
          <TransactionItem title="Stellar Stipend" amount="+4,200.00" category="Income" date="Yesterday" color="tertiary" positive />
          <TransactionItem title="Power Grid" amount="-89.45" category="Utilities" date="2 Days ago" color="primary" />
        </div>
      </section>
    </div>
  );
}

function TransactionItem({ title, amount, category, date, positive }: { title: string, amount: string, category: string, date: string, color: string, positive?: boolean }) {
  return (
    <div className="glass-card rounded-2xl p-5 flex items-center justify-between group hover:bg-white/8 transition-all duration-300 cursor-pointer">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-xl">
          {positive ? '💰' : '✨'}
        </div>
        <div>
          <p className="font-medium text-on-surface">{title}</p>
          <p className="text-xs text-on-surface-variant opacity-60">{date} • {category}</p>
        </div>
      </div>
      <div className="text-right">
        <p className={`font-display text-lg ${positive ? 'text-tertiary' : 'text-on-surface'}`}>{amount}</p>
        <p className="text-[10px] text-on-surface-variant uppercase tracking-widest opacity-40">Processed</p>
      </div>
    </div>
  );
}

// --- Reading Screen ---
function Reading() {
  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="relative group">
        <input 
          type="text" 
          placeholder="Search your library..."
          className="w-full bg-white/5 border-b border-white/10 py-4 pl-12 pr-4 focus:outline-none focus:border-tertiary/50 focus:ring-0 transition-all font-sans text-on-surface placeholder:text-on-surface-variant/40"
        />
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant opacity-40 group-focus-within:text-tertiary transition-colors">🔍</span>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {['All Reads', 'Productivity', 'Sci-Fi', 'Design', 'Philosophy', 'Cosmology'].map((tag, i) => (
          <button key={tag} className={`px-5 py-2 rounded-full text-xs font-bold uppercase tracking-widest whitespace-nowrap transition-all ${i === 0 ? 'bg-tertiary/20 text-tertiary border border-tertiary/30' : 'bg-white/5 text-on-surface-variant hover:bg-white/10'}`}>
            {tag}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <BookCard title="The Architecture of Silence" author="archdaily.com" time="12 min read" excerpt="A deep dive into how physical spaces influence our internal state of stillness..." />
        <BookCard title="Exoplanets and the Future" author="nasa.gov" time="5 min read" excerpt="Recent discoveries of Earth-like worlds in the habitable zones of distant stars." />
        <div className="relative rounded-3xl overflow-hidden glass-panel group min-h-[220px]">
          <img 
            src="https://images.unsplash.com/photo-1464802686167-b939a67a06c1?auto=format&fit=crop&q=80&w=800" 
            className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-700"
            alt="Space"
          />
          <div className="relative z-10 p-8 h-full flex flex-col justify-between italic">
            <div>
              <span className="text-[10px] uppercase font-bold text-tertiary tracking-widest px-2 py-1 bg-tertiary/20 rounded-full">Featured Essay</span>
              <h3 className="text-2xl font-display text-white mt-4">Stardust in our Veins</h3>
            </div>
            <button className="w-full py-3 glass-panel rounded-xl text-sm font-semibold hover:bg-white/10 transition-colors uppercase tracking-[0.2em]">Read Now</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BookCard({ title, author, time, excerpt }: { title: string, author: string, time: string, excerpt: string }) {
  return (
    <div className="glass-card rounded-3xl p-8 flex flex-col justify-between min-h-[220px] hover:border-tertiary/20 transition-all duration-500 group cursor-pointer">
      <div>
        <div className="flex justify-between items-start mb-6">
          <div className="w-10 h-10 rounded-xl glass-panel flex items-center justify-center text-lg">📖</div>
          <span className="text-on-surface-variant group-hover:text-tertiary transition-colors opacity-30">⭐</span>
        </div>
        <h3 className="font-display text-2xl text-primary mb-3 leading-tight line-clamp-2">{title}</h3>
        <p className="text-sm text-on-surface-variant line-clamp-2 opacity-70 leading-relaxed font-sans">{excerpt}</p>
      </div>
      <div className="mt-6 pt-4 border-t border-white/5 flex justify-between items-center text-[10px] text-on-surface-variant uppercase tracking-widest font-semibold">
        <span>{author}</span>
        <span className="text-tertiary">{time}</span>
      </div>
    </div>
  );
}

// --- Todos Screen ---
function Todos() {
  return (
    <div className="max-w-3xl mx-auto space-y-12 animate-in slide-in-from-bottom-4 duration-700">
      <header className="mb-12">
        <h3 className="font-display text-3xl text-primary mb-2">Observation Log</h3>
        <p className="text-on-surface-variant opacity-70 italic font-sans">Focusing your celestial lens on the present moment.</p>
      </header>

      <div className="space-y-12">
        <TodoSection title="Zenith Alignment" color="error" />
        <TodoSection title="Horizon Sync" color="tertiary" />
        <TodoSection title="Nadir Drift" color="on-surface-variant" />
      </div>
    </div>
  );
}

function TodoSection({ title, color }: { title: string, color: string }) {
  const colorClass = color === 'error' ? 'bg-error' : color === 'tertiary' ? 'bg-tertiary' : 'bg-on-surface-variant/20';
  const glowClass = color === 'error' ? 'shadow-[0_0_8px_rgba(255,180,171,0.6)]' : color === 'tertiary' ? 'shadow-[0_0_8px_rgba(233,195,73,0.4)]' : '';

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-2 mb-6 ml-2">
        <div className={`w-2 h-2 rounded-full ${colorClass} ${glowClass}`}></div>
        <p className={`text-xs uppercase tracking-[0.2em] font-bold ${color === 'error' ? 'text-error' : color === 'tertiary' ? 'text-tertiary' : 'text-on-surface-variant'}`}>{title}</p>
      </div>
      <TodoItem text="Review Star Chart Calculations" subtext="Finalize trajectory for the equinox." />
      <TodoItem text="Calibrate Lens Aperture" subtext="Maintenance for deep space clarity." completed />
      <TodoItem text="Update Inventory" subtext="Restock glass wipes and thermal tea." />
    </section>
  );
}

function TodoItem({ text, subtext, completed }: { text: string, subtext: string, completed?: boolean }) {
  return (
    <div className={`glass-card rounded-2xl p-6 transition-all duration-500 group cursor-pointer ${completed ? 'opacity-40' : 'hover:bg-white/8'}`}>
      <div className="flex items-center gap-5">
        <div className={`w-6 h-6 rounded-full border-2 transition-all flex items-center justify-center ${completed ? 'bg-tertiary border-tertiary' : 'border-white/20 group-hover:border-tertiary'}`}>
          {completed && <span className="text-on-tertiary text-xs">✓</span>}
        </div>
        <div>
          <h4 className={`text-lg font-display ${completed ? 'line-through' : ''}`}>{text}</h4>
          <p className="text-xs text-on-surface-variant opacity-60 font-sans mt-0.5">{subtext}</p>
        </div>
      </div>
    </div>
  );
}

// --- Trips Screen ---
function Trips() {
  return (
    <div className="max-w-5xl mx-auto space-y-12 animate-in zoom-in-95 duration-700">
       <div className="relative rounded-[3rem] overflow-hidden h-[500px] glass-panel group transition-all duration-1000 shadow-2xl border-none">
        <img 
          alt="Alps" 
          src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1200"
          className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-12 w-full flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 mb-3 text-tertiary">
              <span className="text-sm">📍</span>
              <span className="text-[10px] uppercase tracking-[0.4em] font-bold">Active Expedition</span>
            </div>
            <h2 className="font-display text-5xl md:text-6xl text-on-surface leading-tight mb-4 tracking-tight">The Celestial Alps</h2>
            <p className="text-on-surface-variant text-xl opacity-80 leading-relaxed font-sans">Sept 14 — Sept 22 • 8 Days of Stillness under the clearest night skies in Europe.</p>
          </div>
          <div className="flex gap-4">
             <button className="px-8 py-4 bg-white/5 border border-white/10 text-white rounded-full font-bold uppercase text-[10px] tracking-widest hover:bg-white/10 transition-all">Modify Plan</button>
             <button className="px-8 py-4 bg-tertiary text-on-tertiary rounded-full font-bold uppercase text-[10px] tracking-widest shadow-xl shadow-tertiary/20 hover:scale-[1.02] transition-transform">Launch Navigation</button>
          </div>
        </div>
      </div>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel rounded-[2rem] p-10 min-h-[400px]">
          <h3 className="font-display text-2xl text-primary mb-8">Navigation Chart</h3>
          <div className="w-full h-64 border border-white/5 rounded-2xl relative flex items-center justify-center p-8">
            <svg className="w-full h-full stroke-tertiary/20 fill-none" viewBox="0 0 100 50">
              <path d="M10,40 Q40,10 60,30 T90,20" strokeDasharray="2 2" />
              <circle cx="10" cy="40" r="1.5" fill="#e9c349" className="animate-pulse" />
              <circle cx="90" cy="20" r="1.5" fill="#e9c349" />
            </svg>
            <div className="absolute left-8 bottom-8 text-[10px] uppercase tracking-widest opacity-40">Depart: Zurich</div>
            <div className="absolute right-8 top-8 text-[10px] uppercase tracking-widest text-tertiary">Arrive: Mt. Pilatus</div>
          </div>
        </div>
        <div className="glass-panel rounded-[2rem] p-10 flex flex-col justify-between">
          <h3 className="font-display text-2xl text-primary mb-6">Preparation</h3>
          <div className="space-y-8">
            <PrepItem label="Essentials" progress={85} />
            <PrepItem label="Stargazing Gear" progress={42} />
          </div>
          <div className="mt-12 pt-8 border-t border-white/5">
             <p className="text-[10px] uppercase tracking-[0.2em] text-tertiary opacity-60 mb-4 font-bold">Missing Items</p>
             <ul className="text-sm text-on-surface-variant space-y-2 opacity-80">
               <li>• Physical Star Chart</li>
               <li>• Thermal lens heater</li>
             </ul>
          </div>
        </div>
      </section>
    </div>
  );
}

function PrepItem({ label, progress }: { label: string, progress: number }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="text-on-surface opacity-80">{label}</span>
        <span className="text-tertiary">{progress}%</span>
      </div>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
        <div className="h-full bg-tertiary rounded-full transition-all duration-1000" style={{ width: `${progress}%` }}></div>
      </div>
    </div>
  );
}

// --- Poetry Screen ---
function Poetry() {
  return (
    <div className="max-w-4xl mx-auto space-y-16 animate-in fade-in duration-1000">
      <header className="text-center md:text-left">
        <h1 className="font-display text-5xl md:text-6xl text-on-surface mb-4 tracking-tight">Collected Verse</h1>
        <p className="text-on-surface-variant text-xl opacity-60 italic font-display max-w-2xl leading-relaxed">"A silent sanctuary for words that resonate in the stillness of the deep cosmic night."</p>
      </header>

      <div className="space-y-12">
        <Poem 
          title="The Solitary Star" 
          lines={["In the dark of the sky,", "where the silent ones dwell,", "one light burns alone,", "casting a silver spell."]} 
          date="14 OCT 2023"
        />
        <Poem 
          title="Echoes of the Void" 
          lines={["What is the sound of the moon as it turns?", "A soft, quiet hum that the universe learns.", "We are but dust in a beautiful dance,", "Caught in the web of a celestial chance."]} 
          date="02 SEP 2023"
          featured
        />
        <Poem 
          title="The Clock of Sand" 
          lines={["Grain by grain,", "the ocean waits.", "While mountains bow", "to ancient fates."]} 
          date="21 AUG 2023"
        />
      </div>
    </div>
  );
}

function Poem({ title, lines, date, featured }: { title: string, lines: string[], date: string, featured?: boolean }) {
  return (
    <article className={`${featured ? 'glass-panel p-12 md:p-20 border-tertiary/20' : 'glass-panel p-10 border-white/5'} rounded-[3rem] transition-all duration-1000 hover:border-tertiary/30 group relative overflow-hidden`}>
      {featured && <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-tertiary/[0.03] rounded-full blur-[120px] -m-48"></div>}
      <div className="relative z-10 text-center md:text-left">
        <h2 className="font-display text-3xl md:text-4xl text-primary mb-10 group-hover:text-tertiary transition-colors duration-700">{title}</h2>
        <div className="space-y-4">
          {lines.map((line, i) => (
            <p key={i} className="font-display text-2xl md:text-3xl text-on-surface-variant italic leading-normal opacity-80">{line}</p>
          ))}
        </div>
        <div className="mt-16 flex justify-between items-center opacity-30 text-[10px] uppercase tracking-widest font-bold">
          <span className="flex items-center gap-2">
            <span className="w-1 h-1 bg-tertiary rounded-full"></span>
            {date}
          </span>
          <span className="scale-150 group-hover:text-tertiary transition-colors">✧</span>
        </div>
      </div>
    </article>
  );
}

// --- Notes Screen ---
function Notes() {
  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-display text-4xl text-tertiary mb-2">Faint Signals</h1>
          <p className="text-on-surface-variant text-lg opacity-60 max-w-xl">Capture fleeting whispers of the cosmos before they fade into the background radiation.</p>
        </div>
        <button className="px-8 py-3 bg-tertiary/10 text-tertiary border border-tertiary/20 rounded-full font-bold uppercase text-[10px] tracking-widest flex items-center gap-2 hover:bg-tertiary hover:text-on-tertiary transition-all duration-500 active:scale-95 shadow-lg shadow-tertiary/5">
          <span className="text-xl">+</span> New Signal
        </button>
      </header>

      <section className="glass-panel rounded-[2.5rem] p-10 border-tertiary/10 relative overflow-hidden focus-within:border-tertiary/30 transition-all duration-700">
        <div className="absolute inset-0 bg-white/[0.01] pointer-events-none"></div>
        <div className="relative z-10">
          <input 
            type="text" 
            placeholder="Signal Header..." 
            className="w-full bg-transparent border-none p-0 font-display text-3xl text-on-surface placeholder:text-on-surface-variant/20 focus:ring-0 mb-6"
          />
          <textarea 
            placeholder="Expand the resonance..."
            className="w-full bg-transparent border-none p-0 text-xl md:text-2xl min-h-[160px] focus:ring-0 placeholder:text-on-surface-variant/20 resize-none font-sans italic opacity-80"
          />
          <div className="mt-10 pt-8 border-t border-white/5 flex justify-between items-center">
            <div className="flex gap-4 opacity-40">
              {['✨', '📷', '📁', '⚖️'].map(icon => <button key={icon} className="hover:opacity-100 transition-opacity">{icon}</button>)}
            </div>
            <button className="bg-tertiary-container/20 text-tertiary px-10 py-4 rounded-full font-bold uppercase text-[10px] tracking-widest hover:bg-tertiary hover:text-on-tertiary transition-all duration-500 shadow-xl shadow-tertiary/10">Capture Signal</button>
          </div>
        </div>
      </section>

      <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
        <NoteItem title="The Silence of the Pillars" text="There is a specific frequency to the stillness that feels less like an absence of sound and more like a presence of ancient data. Maybe the vacuum is just a very high-capacity storage device we haven't learned to read yet." category="Reflection" />
        <NoteItem title="Entropy Plan" text="What if the universe isn't winding down, but simply deciding to take a long, distributed nap?" category="Theory" />
        <div className="glass-panel rounded-[3rem] overflow-hidden p-0 group border-white/5 hover:border-tertiary/20 transition-all duration-700 break-inside-avoid shadow-xl">
          <img src="https://images.unsplash.com/photo-1462331940025-496df97584ce?auto=format&fit=crop&q=80&w=800" alt="Nebula" className="w-full h-56 object-cover opacity-60 grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000" />
          <div className="p-10">
            <span className="text-[10px] uppercase font-bold text-primary/40 tracking-[0.2em] mb-4 block">Archive</span>
            <h3 className="font-display text-2xl text-primary mb-3">Alpha Centauri Dreams</h3>
            <p className="text-sm text-on-surface-variant opacity-70 leading-relaxed font-sans italic">Recurring vision of a dual-sun sunset. Burning copper and magnesium.</p>
          </div>
        </div>
        <NoteItem title="Stardust Flux" text="We are literally atomic debris from supernovae. Our consciousness is a way for the universe to look at itself." category="Cosmology" />
      </div>
    </div>
  );
}

function NoteItem({ title, text, category }: { title: string, text: string, category: string }) {
  return (
    <div className="glass-panel rounded-[2.5rem] p-10 border-white/5 hover:border-tertiary/20 transition-all duration-700 break-inside-avoid group shadow-xl">
       <div className="flex justify-between items-start mb-6">
         <span className="text-[10px] uppercase font-bold text-tertiary/40 tracking-[0.3em]">{category}</span>
         <span className="opacity-0 group-hover:opacity-100 transition-opacity">✧</span>
       </div>
       <h3 className="font-display text-2xl text-on-surface mb-4 leading-snug">{title}</h3>
       <p className="text-on-surface-variant opacity-75 text-base leading-relaxed font-sans">{text}</p>
    </div>
  );
}

// --- Auth Screen ---
function Auth({ onLogin }: { onLogin: () => void }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 overflow-hidden">
      <div className="absolute inset-0 bg-surface">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-tertiary/[0.03] rounded-full blur-[120px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-primary/[0.03] rounded-full blur-[120px]"></div>
      </div>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-panel w-full max-w-[440px] p-10 md:p-14 rounded-[3rem] relative overflow-hidden text-center z-10"
      >
        <div className="w-20 h-20 rounded-full glass-panel mx-auto mb-10 flex items-center justify-center text-tertiary border-tertiary/20 shadow-[0_0_30px_rgba(233,195,73,0.1)]">
          <Settings size={40} className="animate-pulse" />
        </div>
        
        <h1 className="font-display text-4xl text-on-surface mb-4 leading-tight">Welcome Back</h1>
        <p className="text-on-surface-variant font-sans mb-12 opacity-60">Enter your credentials to access the Observatory sanctuary.</p>
        
        <div className="space-y-6 text-left">
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-bold tracking-[0.2em] text-on-surface-variant ml-1">Email Address</label>
            <input type="email" placeholder="observer@cosmos.io" className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-on-surface placeholder:text-on-surface-variant/20 focus:outline-none focus:border-tertiary/30 transition-all font-sans" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center ml-1">
              <label className="text-[10px] uppercase font-bold tracking-[0.2em] text-on-surface-variant">Password</label>
              <button className="text-[10px] text-tertiary font-bold uppercase tracking-widest opacity-60 hover:opacity-100 transition-opacity">Forgotten?</button>
            </div>
            <input type="password" placeholder="••••••••" className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-on-surface placeholder:text-on-surface-variant/20 focus:outline-none focus:border-tertiary/30 transition-all font-sans" />
          </div>
        </div>

        <button 
          onClick={onLogin}
          className="w-full mt-12 py-5 bg-tertiary text-on-tertiary rounded-3xl font-bold uppercase text-xs tracking-[0.2em] shadow-2xl shadow-tertiary/20 hover:scale-[1.02] active:scale-95 transition-all duration-500"
        >
          Enter the Observatory
        </button>
        
        <div className="mt-8 pt-8 border-t border-white/5">
          <button className="text-[10px] text-on-surface-variant font-bold uppercase tracking-widest opacity-40 hover:opacity-100 transition-opacity">Create your constellation</button>
        </div>
      </motion.div>
    </div>
  );
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);

  return (
    <BrowserRouter>
      <Routes>
        <Route 
          path="/login" 
          element={isLoggedIn ? <Navigate to="/habits" replace /> : <Auth onLogin={() => setIsLoggedIn(true)} />} 
        />
        <Route path="/" element={isLoggedIn ? <Layout /> : <Navigate to="/login" replace />}>
          <Route index element={<Navigate to="habits" replace />} />
          <Route path="habits" element={<Habits />} />
          <Route path="finance" element={<Finance />} />
          <Route path="reading" element={<Reading />} />
          <Route path="todos" element={<Todos />} />
          <Route path="trips" element={<Trips />} />
          <Route path="poetry" element={<Poetry />} />
          <Route path="notes" element={<Notes />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
